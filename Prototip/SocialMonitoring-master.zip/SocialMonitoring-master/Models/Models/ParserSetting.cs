﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Models
{
    public class ParserSetting
    {
        public int Id { get; set; }

        public string ParserName { get; set; }

        public string JsonSettings { get; set; }
    }
}
