﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Models
{
    public class TerosistLegal
    {
        public int Id { get; set; }

        public string Inn { get; set; }

        public string Name { get; set; }
    }
}
