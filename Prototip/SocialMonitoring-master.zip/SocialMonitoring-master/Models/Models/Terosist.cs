﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Models
{
    public class Terosist
    {   
        public int Id { get; set; }

        public string Address { get; set; }

        public string Name { get; set; }

        public DateTime BithDay { get; set; }
    }
}
